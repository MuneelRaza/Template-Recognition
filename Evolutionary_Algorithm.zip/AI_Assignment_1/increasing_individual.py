import random
import numpy
from numpy import asarray

from PIL import Image
small_image = Image.open("small_image.jpg")

large_image = Image.open("group_image.jpg")

group_columns, group_rows = large_image.size

population_size = 100

large_image_array = asarray(large_image)


def population_initialization(group_rows, group_coloums, population_size):
    current_population = []
    x_values = []
    y_values = []
    while len(x_values) <= population_size or len(y_values) <= population_size:
        x = random.randint(0, group_rows - 1)
        if len(x_values) <= population_size and x not in x_values:
            x_values.append(x)
        y = random.randint(0, group_coloums - 1)
        if len(y_values) <= population_size and y not in y_values:
            y_values.append(y)
    for i in range(population_size):
        current_population.append((x_values[i], y_values[i]))
    return current_population


def fitness_evaluation(current_generation, large_image, small_image):
    fitness_values = {}
    boothi_columns, boothi_rows = small_image.size
    small_image_array = asarray(small_image)
    for individual in current_generation:
        # individual is passed to frame_boundary function which returns valid frame_boundaries
        valid_frame_boundaries = frame_boundaries(individual, boothi_rows, boothi_columns)
        frame_array = get_frame(valid_frame_boundaries, large_image_array)
        fitness_values[individual] = correlation_coefficient(small_image_array, frame_array)
    return fitness_values


def natural_selection(population_fitness_dictionary):
    sorted_population = sorted(population_fitness_dictionary.items(), key=lambda x: x[1], reverse=True)
    sorted_population = dict(sorted_population)
    return sorted_population


def next_generation(sorted_population, group_rows, group_columns):
    # final list of new population we got after crossover
    new_generation = []
    # population passed to for sorting on the basis of fitness values
    sorted_fit_population = []
    for item in sorted_population:
        sorted_fit_population.append(item)
    new_generation.append(sorted_fit_population[0])
    # appending best individual of the population and its fitness value
    best_fit_individuals.append(sorted_fit_population[0])
    best_fitness_values.append(sorted_population[sorted_fit_population[0]])
    fitness_list = numpy.array(list(sorted_population.values()))
    mean_fitness_list.append(numpy.mean(fitness_list))
    # mean_fitness_list.append(numpy.array(list(sorted_population.values())))
    # generating new population starts here
    # take two parents at a time
    for i in range(0, len(sorted_fit_population), 2):
        if i < len(sorted_fit_population) - 1:  # ignoring last two individuals in case of odd population size
            parent_1 = sorted_fit_population[i]
            parent_2 = sorted_fit_population[i + 1]
    # convert into binary and concatenate the bits
            parent_1_binary = decimal_to_binary_x(parent_1[0]) + decimal_to_binary_y(parent_1[1])
            parent_2_binary = decimal_to_binary_x(parent_2[0]) + decimal_to_binary_y(parent_2[1])
            # child creation process ensuring uniqueness
            tooka = random.randint(4, 15)
        # select random number between 0 and 18
        # crossover
            child_1_binary = parent_1_binary[:tooka] + parent_2_binary[tooka:]
            child_2_binary = parent_2_binary[:tooka] + parent_1_binary[tooka:]
            # mutation (change bit from 0 to 1 and 1 to 0)
            if i == len(sorted_fit_population) // 2:
                child_1_binary = mutation(child_1_binary, tooka)
                child_2_binary = mutation(child_2_binary, tooka)
                # new_tooka = random.randint(0, 18)
                # while new_tooka == tooka:
                #     new_tooka = random.randint(0, 18)
                # child_1_binary = mutation(child_1_binary, new_tooka)
                # child_2_binary = mutation(child_2_binary, new_tooka)
            new_generation.append((binaryToDecimal(child_1_binary[:9]), binaryToDecimal(child_1_binary[9:])))
            new_generation.append((binaryToDecimal(child_2_binary[:9]), binaryToDecimal(child_2_binary[9:])))

    return new_generation


def get_frame(frame_boundary, large_image_array):
    frame_array = []
    for row in range(frame_boundary[0][0], frame_boundary[2][0]):
        temp_row = []
        for column in range(frame_boundary[0][1], frame_boundary[1][1]):
            temp_row.append(large_image_array[row, column])
        frame_array.append(temp_row)
    frame_array = numpy.array(frame_array)
    return frame_array


# gives the accurate frame boundary with respect to the given individual
def frame_boundaries(individual, boothi_rows, boothi_columns):
    frame_boundary = []
    # out of the column limit of bigger picture
    if individual[1] + boothi_columns > group_columns:
        # safe on rows
        if individual[0] + boothi_rows <= group_rows:
            top_right = (individual[0], group_columns - 1)
            top_left = (individual[0], group_columns - boothi_columns - 1)
            bottom_right = (individual[0] + boothi_rows, group_columns - 1)
            bottom_left = (individual[0] + boothi_rows, group_columns - boothi_columns - 1)
            frame_boundary.append(top_left)
            frame_boundary.append(top_right)
            frame_boundary.append(bottom_left)
            frame_boundary.append(bottom_right)
            return frame_boundary
        # not safe on rows
        else:
            bottom_right = (group_rows - 1, group_columns - 1)
            bottom_left = (group_rows - 1, group_columns - boothi_columns - 1)
            top_left = (group_rows - boothi_rows - 1, group_columns - boothi_columns - 1)
            top_right = (group_rows - boothi_rows - 1, group_columns - 1)
            frame_boundary.append(top_left)
            frame_boundary.append(top_right)
            frame_boundary.append(bottom_left)
            frame_boundary.append(bottom_right)
            return frame_boundary
    else:
        # if we are in valid columns and now check if we are in valid rows
        # out of the boundary of rows of bigger picture
        if individual[0] + boothi_rows > group_rows:
            bottom_left = (group_rows - 1, individual[1])
            bottom_right = (group_rows - 1, individual[1] + boothi_columns)
            top_left = (group_rows - boothi_rows - 1, individual[1])
            top_right = (group_rows - boothi_rows - 1, individual[1] + boothi_columns)
            frame_boundary.append(top_left)
            frame_boundary.append(top_right)
            frame_boundary.append(bottom_left)
            frame_boundary.append(bottom_right)
            return frame_boundary
        # within the boundary of rows of bigger picture
        else:
            top_left = individual
            top_right = (individual[0], individual[1] + boothi_columns)
            bottom_left = (individual[0] + boothi_rows, individual[1])
            bottom_right = (individual[0] + boothi_rows, individual[1] + boothi_columns)
            frame_boundary.append(top_left)
            frame_boundary.append(top_right)
            frame_boundary.append(bottom_left)
            frame_boundary.append(bottom_right)
            return frame_boundary


def correlation_coefficient(T1, T2):
    numerator = numpy.mean((T1 - T1.mean()) * (T2 - T2.mean()))
    denominator = T1.std() * T2.std()
    if denominator == 0:
        return 0
    else:
        result = numerator / denominator
        return result


def decimal_to_binary_x(n):
    b = bin(n).replace("0b", "")
    extension = 9 - len(b)
    b = extension*str(0) + b
    return b


def decimal_to_binary_y(n):
    b = bin(n).replace("0b", "")
    extension = 10- len(b)
    b = extension * str(0) + b
    return b


def binaryToDecimal(n):
    return int(n, 2)


def mutation(binary, position):
    mutated = ''
    for i in range(len(binary)):
        if i == position:
            if binary[i] == '0':
                mutated = mutated + '1'
            else:
                mutated = mutated + '0'
        else:
            mutated = mutated + binary[i]
    return mutated


fitness_threshold = 0.95
max_generations = 500
best_fit_individuals = []
best_fitness_values = []
mean_fitness_list = []
first_population = population_initialization(group_rows, group_columns, population_size)
first_fitness = fitness_evaluation(first_population, large_image, small_image)
first_selection = natural_selection(first_fitness)
new_generation = next_generation(first_selection, group_rows, group_columns)

for i in range(max_generations):
    if max(best_fitness_values) >= fitness_threshold:
        break
    # print("Population Size: ", len(new_generation))
    next_fitness = fitness_evaluation(new_generation, large_image, small_image)
    next_selection = natural_selection(next_fitness)
    new_generation = next_generation(next_selection, group_rows, group_columns)


generation_number = [i for i in range(1, len(best_fit_individuals) + 1)]

# Importing packages
import matplotlib.pyplot as plt

plt.plot(generation_number, best_fitness_values)

# Plot another line on the same chart/graph
plt.plot(generation_number, mean_fitness_list)
plt.ylabel("Fitness")
plt.xlabel("Generations")
location = 0
legend_drawn_flag = True
plt.legend(["max fitness", "mean fitness"], loc=0, frameon=legend_drawn_flag)
plt.show()



